create definer = agata@localhost view vw_pmb as
select `pendaftar`.`tahun_ajaran`             AS `tahun_ajaran`,
       `pendaftar`.`jumlah_pendaftar`         AS `jumlah_pendaftar`,
       `lolos_seleksi`.`jumlah_lolos_seleksi` AS `jumlah_lolos_seleksi`,
       `registrasi`.`jumlah_registrasi`       AS `jumlah_registrasi`,
       `daya_tampung`.`jumlah_daya_tampung`   AS `jumlah_daya_tampung`
from ((((select `ds`.`tahun_ajaran` AS `tahun_ajaran`, count(0) AS `jumlah_pendaftar`
         from (`ftidw`.`fact_pmb` `fpmb`
                  join `ftidw`.`dim_semester` `ds` on (`fpmb`.`id_semester` = `ds`.`id_semester`))
         group by `ds`.`tahun_ajaran`) `pendaftar` join (select `ds`.`tahun_ajaran` AS `tahun_ajaran`,
                                                                count(0)            AS `jumlah_lolos_seleksi`
                                                         from (`ftidw`.`fact_pmb` `fpmb`
                                                                  join `ftidw`.`dim_semester` `ds`
                                                                       on (`fpmb`.`id_semester` = `ds`.`id_semester`))
                                                         where `fpmb`.`id_tanggal_lolos_seleksi` is not null
                                                           and `fpmb`.`id_prodi_diterima` = 9
                                                         group by `ds`.`tahun_ajaran`) `lolos_seleksi` on (`pendaftar`.`tahun_ajaran` = `lolos_seleksi`.`tahun_ajaran`)) join (select `ds`.`tahun_ajaran` AS `tahun_ajaran`,
                                                                                                                                                                                      count(0)            AS `jumlah_registrasi`
                                                                                                                                                                               from (`ftidw`.`fact_pmb` `fpmb`
                                                                                                                                                                                        join `ftidw`.`dim_semester` `ds`
                                                                                                                                                                                             on (`fpmb`.`id_semester` = `ds`.`id_semester`))
                                                                                                                                                                               where `fpmb`.`id_tanggal_registrasi` is not null
                                                                                                                                                                                 and `fpmb`.`id_prodi_diterima` = 9
                                                                                                                                                                               group by `ds`.`tahun_ajaran`) `registrasi` on (`pendaftar`.`tahun_ajaran` = `registrasi`.`tahun_ajaran`))
         join (select `ds`.`tahun_ajaran` AS `tahun_ajaran`, `ddt`.`jumlah` AS `jumlah_daya_tampung`
               from (`ftidw`.`dim_daya_tampung` `ddt`
                        join `ftidw`.`dim_semester` `ds` on (`ddt`.`id_semester` = `ds`.`id_semester`))
               where `ddt`.`id_prodi` = 9) `daya_tampung`
              on (`pendaftar`.`tahun_ajaran` = `daya_tampung`.`tahun_ajaran`))
order by `pendaftar`.`tahun_ajaran`;

